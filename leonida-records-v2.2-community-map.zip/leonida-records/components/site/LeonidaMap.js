'use client';

// Community map by State of Leonida. It is an external, unofficial community
// project and is intentionally embedded instead of recreated locally.
export const COMMUNITY_MAP = {
  url: 'https://map.stateofleonida.net/',
  home: 'https://map.stateofleonida.net/',
  name: 'State of Leonida',
};

/**
 * The homepage world section uses the live State of Leonida community map.
 * The archive map remains available as code elsewhere, but the public world
 * section intentionally shows the community map directly so it stays current.
 */
export function LeonidaMap({ t }) {
  return (
    <div className="lmap">
      <div className="lmap__frame lmap__frame--community">
        <div className="lmap__topbar">
          <span className="lmap__badge">
            <span className="lmap__badge-dot" />
            {t.communityTab}
          </span>
          <a
            className="lmap__barbtn"
            href={COMMUNITY_MAP.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            {t.open} ↗
          </a>
        </div>

        <iframe
          src={COMMUNITY_MAP.url}
          title={t.iframeTitle}
          loading="lazy"
          referrerPolicy="strict-origin-when-cross-origin"
          allow="fullscreen"
          allowFullScreen
        />
      </div>

      <p className="world__note">
        {t.creditBefore}{' '}
        <a href={COMMUNITY_MAP.home} target="_blank" rel="noopener noreferrer">
          {COMMUNITY_MAP.name}
        </a>{' '}
        {t.creditAfter}
      </p>
    </div>
  );
}
