# Vercel: estructura correcta del proyecto

Este archivo explica el error `No Next.js version detected`.

Vercel debe apuntar a la carpeta que contiene directamente `package.json`.

La estructura de este ZIP ya está corregida para que `package.json` esté en la raíz:

```text
leonida-records/
├── app/
├── components/
├── lib/
├── public/
├── scripts/
├── styles/
├── supabase/
├── package.json
├── package-lock.json
├── next.config.mjs
└── ...
```

## Si el repositorio de GitHub está vacío

Descomprime este ZIP y sube **el contenido de esta carpeta**, no el ZIP y no una carpeta `leonida-records` adicional.

## Si el repositorio ya contiene el proyecto

En GitHub, reemplaza los archivos actuales por los de esta versión. El `package.json` debe quedar en la raíz del repositorio.

En Vercel:

- Framework Preset: `Next.js`
- Root Directory: `.` (raíz del repositorio)
- Build Command: `npm run build`
- Install Command: `npm install`

No necesitas cambiar código para añadir posteriormente el dominio.
